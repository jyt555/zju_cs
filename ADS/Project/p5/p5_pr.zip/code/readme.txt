This holder[code] contains:
    main.c
    testcase.txt
    readme.txt

How to test the program:
    compile and run main.c (e.g. with gcc)
    input test case and check the output

If you want to construct your own test case,
the format of input and output is explained in detail in the report.

Thank.
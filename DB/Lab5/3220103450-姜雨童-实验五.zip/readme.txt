This zip includes:
    source code in submit.zip
    report

How to execute my LibraryManagementSystem:
1.  run the Main.java
    and you can see the initialization scene:
    |---Welcome to the library---
    |Input the number to operate:
    | [1] store book         [2] delta book stock        [3] batch store books
    | [4] remove book        [5] modify book info        [6] query book
    | [7] borrow book        [8] return book             [9] show borrow history
    |[10] register card     [11] remove card            [12] show cards
    |[13] reset database     [0] exit
    |
    |Please enter your choice:
2.  enter the number to choose operation
    in each operation, there will be description and tip information
3.  enter [0] to exit
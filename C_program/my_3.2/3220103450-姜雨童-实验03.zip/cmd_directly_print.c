//cmd_directly_print

#include "cmd.h"

void cmd_directly_print(char *cp[])
{
	for(i = 0;i < n;i++)
	printf("%s",cp[i]);
}

#include "head.h"

char	a[200],c;
int		i = 0,word = 0,n = -1,m,judge,pause,p;

int main(void) 
{
	scan();
	print();
	return 0;
}

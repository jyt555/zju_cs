#ifndef __HEAD_H__
#define __HEAD_H__

#include <stdio.h>

void scan();
void print();
int fjudge(int x);
void Pig_Latin(int judge);
int vowel(char ch);
int letter(char ch);

extern char	a[200],c;
extern int	i,word,n,m,judge,pause,p;

#endif	//__HEAD_H__ 

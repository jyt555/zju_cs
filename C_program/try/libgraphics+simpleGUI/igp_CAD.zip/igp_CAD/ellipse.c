/*
 * ellipse.c -- ��Բͼ����ز���������ʵ��
 */
  
#include <math.h>
#include <string.h>
#include "graphics.h"
#include "extgraph.h"
#include "random.h"
#include "ellipse.h"
#include "cad.h"

//�������һ����Բ 
EllipseT GenEllipse(void)
{	
	EllipseT eptr = New(EllipseT);
	eptr->cx = RandomReal(1.0, GetWindowWidth()-1.0);
	eptr->cy = RandomReal(1.0, GetWindowHeight()-1.0);
	eptr->rx = RandomReal(0.5, 3.0);
	eptr->ry = RandomReal(0.5, 2.0);
	eptr->PenSize = GetPenSize();
	eptr->color = GetPenColor();
	eptr->isSelected = FALSE;
	return eptr;
}

/*For ellipse*/
void DrawCenteredEllipse(void *ellipse)
{
	if (ellipse == NULL) return;
	
	EllipseT eptr = (EllipseT)ellipse;
	int pensize = GetPenSize();
	string color = GetPenColor();

	SetPenSize(eptr->PenSize);
	SetPenColor(eptr->color);
	MovePen(eptr->cx + eptr->rx, eptr->cy);
    DrawEllipticalArc(eptr->rx, eptr->ry, 0.0, 360.0);
    SetPenSize(pensize);
    SetPenColor(color);
}

bool EllipseEqual(void *ellipse1, void *ellipse2)
{
	if (ellipse1 == NULL || ellipse2 == NULL) return FALSE;
	
	EllipseT eptr1 = (EllipseT)ellipse1, eptr2 = (EllipseT)ellipse2;

	return eptr1->cx == eptr2->cx && eptr1->cy == eptr2->cy &&
           eptr1->rx == eptr2->rx && eptr1->ry == eptr2->ry;

}

double distEllipse(double x, double y, EllipseT ellipse)
{
	return fabs(x-ellipse->cx) + fabs(y-ellipse->cy);
}

EllipseT SelectNearestNodeE(linkedlistADT list, double mx, double my)
{
	linkedlistADT nearestnode = NULL, ptr;
	double mindistance, dist;

	ptr = NextNode(list, list);
	if (ptr == NULL) return NULL;
    nearestnode = ptr;
	mindistance = distEllipse(mx, my, (EllipseT)NodeObj(list, ptr));
	while (NextNode(list, ptr) != NULL) {
		ptr = NextNode(list, ptr);
  	    dist = distEllipse(mx, my, (EllipseT)NodeObj(list, ptr));
		if (dist < mindistance) {
			nearestnode = ptr;
			mindistance = dist;
		}
	}
	minDistance[ELLIPSE] = mindistance;

	return (EllipseT)NodeObj(list, nearestnode);
}

void SaveEllipseObjs(linkedlistADT list)
{
	int nodeCount = CountListNodes(list);//ͳ��������ʵ�ʽ���� 
	fwrite(&nodeCount, sizeof(nodeCount), 1, fp);//��������
    TraverseLinkedList(list, SaveEllipseD);
}

void SaveEllipseD(void *obj)
{
	EllipseT eptr = (EllipseT)obj;
	fwrite(eptr, sizeof(*eptr), 1, fp);//������ԲԪ�� 
	int colorlen = strlen(eptr->color)+1;//�������Բ��ɫ�ַ������� 
	fwrite(&colorlen, sizeof(colorlen), 1, fp);//������ɫ�ַ������� 
	fwrite(eptr->color, colorlen, 1, fp);//������ɫ�ַ���
} 

void ReadEllipseObjs(linkedlistADT list)
{
	int nodeCount,i;
	fread(&nodeCount, sizeof(nodeCount), 1, fp);
	for (i = 0; i < nodeCount; i++) {
		EllipseT eptr = New(EllipseT);
		fread(eptr, sizeof(*eptr), 1, fp);
		int colorlen;
		fread(&colorlen, sizeof(colorlen), 1, fp);//��ȡ�ַ�������
		eptr->color = (string)GetBlock(colorlen);//��������ɫ�ַ������ڴ�ռ� 
		fread(eptr->color, colorlen, 1, fp);//��ȡ��ɫ�ַ��� 
		InsertNode(list, NULL, eptr);
	}
}

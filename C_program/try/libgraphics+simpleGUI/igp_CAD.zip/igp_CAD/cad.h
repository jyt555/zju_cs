#ifndef __CAD_H__
#define __CAD_H__

#define NLIST     4
#define LINE      0
#define RECT      1
#define ELLIPSE   2
#define STRING    3

#define SYSCOLOR "Red"  /*Ĭ�ϻ�ͼ��ɫ*/

extern double minDistance[NLIST];

extern FILE *fp;

extern int nodeCount;

void CountNodes(void *obj);
int CountListNodes(linkedlistADT list);

#endif //__CAD_H__

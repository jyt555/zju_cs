igp_keyboard.c	键盘交互示例程序
igp_char.c		字符输入交互示例程序
igp_mouse.c	鼠标交互示例程序
igp_timer.c	定时器示例程序
igp.c		综合键盘、字符输入、鼠标和定时器等交互示例程序

igp_cursorcharA.c	带闪烁光标的字符输入示例，其中：后退擦除汉字一次擦除，圆和文本分别采用结构类型表示
igp_cursorcharB.c	带闪烁光标的字符输入示例，其中：后退擦除汉字一次擦除，圆和文本分别采用结构指针类型表示（需申请空间）

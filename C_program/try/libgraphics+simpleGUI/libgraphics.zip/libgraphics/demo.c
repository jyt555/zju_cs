/*
 * File: demo.c
 * -------------
 * This program draws a circle.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "graphics.h"
#include "extgraph.h" 
#include "genlib.h"
#include "conio.h"
#include <windows.h>
#include <olectl.h>
#include <stdio.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>

void DrawCenteredCircle(double x, double y, double r);
void DrawRect(double x1, double y1, double x2, double y2);

/* Main program */

void Main()
{
    double cx, cy;

    InitGraphics();
    cx = GetWindowWidth() / 2;
    cy = GetWindowHeight() / 2;

    SetPenColor("red");
    SetPenSize(2);

    DrawCenteredCircle(cx, cy, 2.0); 
    DrawRect(cx - 1, cy - 1, cx + 1, cy + 1);
}

/*
 * Function: DrawCenteredCircle
 * Usage: DrawCenteredCircle(x, y, r);
 * -----------------------------------
 * This function draws a circle of radius r with its
 * center at (x, y).
 */

void DrawCenteredCircle(double x, double y, double r)
{
    MovePen(x + r, y);
    DrawArc(r, 0, 360);
}

void DrawRect(double x1, double y1, double x2, double y2)
{
	MovePen(x1, y1);
	DrawLine(0.0, y2-y1);
	DrawLine(x2-x1, 0.0);
	DrawLine(0.0, y1-y2);
	DrawLine(x1-x2, 0.0);
}


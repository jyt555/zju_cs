libgraphics	图形库函数实现源文件目录
include		图形库接口文件目录
house.c		画一个房子
house0.c	画一个房子，并显示一行文本
house1.c	输入笔划、颜色和起始位置坐标，画一个房子
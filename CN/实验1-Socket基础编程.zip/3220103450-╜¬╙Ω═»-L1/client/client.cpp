#include "../packet/packet.h"
#include "client.h"
using namespace std;

//*===== Class: Valid =====*/
bool Valid::is_valid(const char c, const string& input)
{
    Valid rtn;
    switch (c) {
        case 'o': return rtn.is_valid_option(input);
        case 'i': return rtn.is_valid_ip(input);
        case 'd': return rtn.is_valid_id(input);
        case 'p': return rtn.is_valid_port(input);
        default: return false;
    }
}
bool Valid::is_valid_option(const string& input)
{
    if (!isdigit(input[0]))
        throw runtime_error("[wrong input]");
    int op = stoi(input);
    bool res = (!is_connected && op >= 1 && op <= 2) || (is_connected && op >= 1 && op <= 6);
    return res;
}
bool Valid::is_valid_ip(const string& input)
{
    regex ip(R"((\d{1,3}\.){3}\d{1,3})"); // regular expression: 0-999, need more check (TODO).
    return regex_match(input, ip);
}
bool Valid::is_valid_id(const string& input)
{
    int id = stoi(input);
    return (id >= 0 && id < 256);
}
bool Valid::is_valid_port(const string& input)
{
    int port = stoi(input);
    return (port >= 1024 && port <= 65535); // port below 1023 are reserved for privileged users
}


//*===== Class: Interaction =====*/
int Interaction::print_menu()
{
    cout << "\033[44m+==== client: function menu ====+\033[0m" << endl;
    if (!is_connected)
    {
        cout << "\033[44m| [1] connect                   |\033[0m" << endl;
        cout << "\033[44m| [2] quit                      |\033[0m" << endl;
    } else {
        cout << "\033[44m| [1] get time                  |\033[0m" << endl;
        cout << "\033[44m| [2] get name                  |\033[0m" << endl;
        cout << "\033[44m| [3] get info list             |\033[0m" << endl;
        cout << "\033[44m| [4] send info                 |\033[0m" << endl;
        cout << "\033[44m| [5] disconnect                |\033[0m" << endl;
        cout << "\033[44m| [6] quit                      |\033[0m" << endl;
    }
    cout << "\033[44m+===============================+\033[0m" << endl;
    cout << "\033[32m[System]\033[0m Please input option: " << endl;
    cout << "\033[34m[Client]\033[0m ";

    optional<string> op = valid_input('o');
    if (op.has_value())
        return stoi(op.value()); // return option
    else
        return is_connected ? 6 : 2; // return to quit
}
optional<string> Interaction::valid_input(const char c)
{
    Valid check;
    string s;
    while (1) {
        try {
            getline(cin, s);
            if (s == "-1") // input -1 to quit
                return nullopt;
            else if (check.is_valid(c, s))
                return s;
            else
                throw runtime_error("[wrong input]");
        } catch (const exception& e) {
            cout << "\033[31m[System]\033[0m Exception: " << e.what() << endl;
            cout << "\033[32m[System]\033[0m Please input again: " << endl;
            cout << "\033[34m[Client]\033[0m ";
            cin.clear(); // clear the wrong input
            cin.ignore(1024, '\n');
        }
    }
}
optional<pair<string, unsigned int>> Interaction::input_ip_and_port()
{
    pair<string, unsigned int> rtn;

    cout << "\033[32m[System]\033[0m input the IP of server:(input -1 to quit)" << endl;
    optional<string> ip = valid_input('i');
    if (ip.has_value())
        rtn.first = ip.value();
    else
        return nullopt;

    cout << "\033[32m[System]\033[0m input the port of server:(input -1 to quit)" << endl;
    optional<string> port = valid_input('p');
    if (port.has_value())
        rtn.second = stoul(port.value());
    else
        return nullopt;

    return rtn;
}
optional<pair<char, string>> Interaction::input_id_and_msg()
{
    pair<char, string> rtn;
    
    cout << "\033[32m[System]\033[0m input the id of client to list info:(input -1 to quit)" << endl;
    optional<string> id = valid_input('d');
    if (id.has_value())
        rtn.first = stoi(id.value());
    else
        return nullopt;

    cout << "\033[32m[System]\033[0m input the message to send:" << endl;
    string msg;
    getline(cin, msg);
    rtn.second = msg;

    return rtn;
}


//*===== Main Function: Client =====*/
void recv_msg_thread()
{
    while (1)
    {
        char buf[MAXSIZE];
        memset(buf, 0, sizeof(buf)); // clear the buf
        recv(tcp_socket, buf, sizeof(buf) - 1, 0); // recv msg
        auto p = to_packet(buf);
        memset(buf, 0, sizeof(buf));
        Packet recv_packet;
        if(!p.has_value()) 
            continue;
        else 
            recv_packet = p.value();
        recv_respond_time++;
        cout << "\033[33m[Server]\033[0m " << recv_packet.get_msg() << " " << recv_respond_time << endl;
    }
}
void Client()
{
    while (1)
    {
        if (begin_client)
        {
            begin_client = false;
            cout << "\033[32m[System]\033[0m Welcome to client!" << endl;
        }

        int op = Interaction::print_menu();

        /* quit */
        if (!is_connected && op == 2)
            break;
        
        /* connect */
        if (!is_connected && op == 1)
        {
            tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
            auto dst = Interaction::input_ip_and_port();
            if (!dst.has_value()) break;

            struct sockaddr_in serv_addr;
            memset(&serv_addr, 0, sizeof(serv_addr));
            serv_addr.sin_family = AF_INET;
            serv_addr.sin_port = htons(dst.value().second);
            serv_addr.sin_addr.s_addr = inet_addr(dst.value().first.c_str());
        
            if (connect(tcp_socket, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) != -1)
            {
                cout << "\033[32m[System]\033[0m Successfully connect!" << endl;
                is_connected = true;
                thread t(recv_msg_thread);
                t.detach();
            } else {
                cout << "\033[31m[System]\033[0m Failed to connect." << endl;
                is_connected = false;
            }
            continue;
        }

        /* send request to server */
        if (is_connected)
        {
            Packet sendmsg;
            optional<pair<char, string>> info;
            switch (op) {
                case 1: sendmsg.init_packet('t'); break; // get time
                case 2: sendmsg.init_packet('n'); break; // get name
                case 3: sendmsg.init_packet('i'); break; // get info list
                case 4:
                    info = Interaction::input_id_and_msg();
                    if (info.has_value()) // send info
                        sendmsg.init_packet('s', info.value().first, info.value().second);
                    else
                        throw ("[Error] Wrong id, please check it.");
                    break;
                case 5:
                    sendmsg.init_packet('d'); // disconnect
                    is_connected = false; break;
                case 6:
                    sendmsg.init_packet('d'); // first disconnect and then quit
                    is_connected = false; break;
                default: break;
            }
            try {
                string s = sendmsg.to_string();
                const char* msg = s.c_str();

            #if TEST
                for(int i = 1; i <= 100; i++){
                    if(send(tcp_socket, msg, s.size(), 0) == -1)
                        throw("[Error] Failed to send request.");
                    sleep(0);
                }
                this_thread::sleep_for(chrono::seconds(1));     
                cout << "\033[32m[System]\033[0m Successfully send request." << endl;
                this_thread::sleep_for(chrono::seconds(1));                
            #else 
                if (send(tcp_socket, msg, s.size(), 0) == -1)
                    throw ("[Error] Failed to send request.");
                else {
                    cout << "\033[32m[System]\033[0m Successfully send request." << endl;
                    this_thread::sleep_for(chrono::seconds(1));
                }
            #endif // end TEST

                if (!is_connected)
                    close(tcp_socket);
            } catch (const exception& e) {
                cout << "\033[31m[System]\033[0m exception: " << e.what() << endl;
            }
        }
    }
    this_thread::sleep_for(chrono::seconds(5));
    cout << "\033[32m[System]\033[0m Close client successfully." << endl;
}

int main()
{
    Client();
    return 0;
}
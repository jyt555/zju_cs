#ifndef _CLIENT_H_
#define _CLIENT_H_

#include<bits/stdc++.h>
using namespace std;

#define MSG_HEAD "cpszd"
#define MAXSIZE 1024
#define TEST 0
bool is_connected = false;
bool begin_client = true;
int tcp_socket;
int recv_respond_time = -1;
mutex mtx;

class Valid
{
    public:
        static bool is_valid(const char c, const string& input); // c is the type of input: 'o'/'i'/'d'/'p'
        static bool is_valid_option(const string& input); // option in menu
        static bool is_valid_ip(const string& input);
        static bool is_valid_id(const string& input);
        static bool is_valid_port(const string& input);
};
class Interaction
{
    public:
        static int print_menu();
        static optional<string> valid_input(const char c); // c is the type of input: 'o'/'i'/'d'/'p'
        static optional<pair<string, unsigned int>> input_ip_and_port();
        static optional<pair<char, string>> input_id_and_msg();
};

#endif // end _CLIENT_H_
Lab1
|
|_client
|   |_client.h
|   |_client.cpp
|   |_client
|
|_packet
|   |_packet.h
|   |_packet.cpp
|
|_server
|   |_server.h
|   |_server.cpp
|   |_server

run in Linux:

[compile](has done):
L1/server$ g++ -std=c++17 -o server server.cpp ../packet/packet.cpp
L1/client$ g++ -std=c++17 -o client client.cpp ../packet/packet.cpp

[run]:
L1/server$ ./server
L1/client$ ./client

Thanks :)
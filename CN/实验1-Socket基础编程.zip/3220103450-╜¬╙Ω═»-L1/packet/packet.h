#ifndef _PACKET_H_
#define _PACKET_H_

#include<bits/stdc++.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<arpa/inet.h>
#include<netinet/in.h>

using namespace std;

#define PACKET_FLAG "cpszd" // msg packet flag

class Packet
{
    private:
        char type;
        char dst;
        string msg;

    public:
        // ctor
        Packet(){};
        Packet(char type);
        Packet(char type, string data);
        Packet(char type, char dst, string data);

        void init_packet(char type, char dst = '1', string data = "1"); // initialize packet
        char get_type() {return type;};
        char get_dst();
        string get_msg() {return msg;};
        string to_string(); // cast packet to string
};
optional<Packet> to_packet(string recv_msg); // cast string to packet

#endif // end _PACKET_H_
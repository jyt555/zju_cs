#include "packet.h"
using namespace std;

Packet::Packet(char type)
{
    this->init_packet(type, '1', "");
}
Packet::Packet(char type, string data)
{
    this->init_packet(type, '1', data);
}
Packet::Packet(char type, char dst, string data)
{
    this->init_packet(type, dst, data);
}
void Packet::init_packet(char type, char dst, string data)
{
    this->type = type;
    this->dst = dst;
    this->msg = data;
}

char Packet::get_dst()
{
    if (type == 's') return dst; // get dst to send msg iff msg_type is 's'
    else return -1;
}
string Packet::to_string()
{
    string rtn = PACKET_FLAG;
    rtn.push_back(type);
    rtn.push_back(dst);
    rtn.append(msg);
    return rtn;
}
optional<Packet> to_packet(string recv_msg)
{
    Packet rtn;
    string msg;
    string flag = PACKET_FLAG;

    // check: incomplete msg or wrong flag => return null
    if (recv_msg.length() < (flag.length() + 3) || recv_msg.substr(0, flag.length()) != flag)
        return nullopt;
    
    // amalyse msg
    try {
        msg = recv_msg.substr(flag.length() + 2);
    } catch (exception& e) {
        cerr << "[Exception] " << typeid(e).name() << endl;
        cout << "[Caught exception] " << e.what() << endl;
        exit(1);
    }
    rtn.init_packet(recv_msg[flag.length()], recv_msg[flag.length() + 1], msg);
    return rtn;
}
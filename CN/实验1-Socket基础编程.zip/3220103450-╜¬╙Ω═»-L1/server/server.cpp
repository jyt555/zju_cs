#include "../packet/packet.h"
#include "server.h"

//*===== Class: Server =====*/
Server::Server()
{
    for (int i = 0; i < MAX_CLIENT; i++)
        client_list_occupied[i] = 0;

    server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sockfd == -1)
        throw ("[Error] Failed to create server socket.");
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY); 

    if (bind(server_sockfd, (sockaddr*)&server_addr, sizeof(server_addr)) != 0)
    {
        close(server_sockfd);
        throw ("[Error] Failed to bind.");
    }
    cout << "\033[32m[System]\033[0m Successfully bind port: " << PORT << endl;

    if (listen(server_sockfd, MAX_WAITLOG) != 0)
    {
        close(server_sockfd);
        throw ("[Error] Failed to listen.");
    }
    cout << "\033[32m[System]\033[0m Successfully initialize the server." << endl;
}

void Server::server_on()
{
    cout << "\033[33m===== Server =====\033[0m" << endl;
    cout << "\033[32m[System]\033[0m Waiting for client to connect..." << endl;
    while (1)
    {
        sockaddr_in client_addr;
        socklen_t client_addr_len = sizeof(client_addr);
        int client_sockfd = accept(server_sockfd, (sockaddr*)&client_addr, &client_addr_len);
        if (client_sockfd == -1)
        {
            cout << "\033[31m[System]\033[0m Failed to accept request from client." << endl;
            continue;
        }

        cout << endl;
        cout << "\033[32m[System]\033[0m A client connected." << endl;
        cout << "        |_ client IP: " << inet_ntoa(client_addr.sin_addr) << endl;
        cout << "        |_ client port: " << ntohs(client_addr.sin_port) << endl;

        int num = get_list_num();
        client_list[num].client_sockfd = client_sockfd;
        client_list[num].client_addr = client_addr;
        occupy_client_list(num);

        pthread_t thread;
        struct thread_info info = {num, client_sockfd, client_addr, this};
        pthread_create(&thread, NULL, handle_client, (void*)&info);      
    }
}

void Server::rst_client_list(int num)
{
    client_list_occupied[num] = 0;
    client_list.erase(num);
}

string Server::get_list()
{
    stringstream ss;
    ss << endl;
    for (auto it = client_list.begin(); it != client_list.end(); it++)
    {
        auto tmp = (it->second).client_addr;
        ss << "id " << it->first + 1 << ": " << inet_ntoa(tmp.sin_addr) << " " << ntohs(tmp.sin_port) << endl;
    }
    return ss.str();
}
int Server::get_list_num()
{
    for (int i = 0; i < MAX_CLIENT; i++)
        if (!client_list_occupied[i]) return i;
    return -1;
}
int Server::find_in_list(int id)
{
    return (client_list_occupied[id] == 1) ? client_list[id].client_sockfd : -1;
}
bool Server::is_client_list_empty()
{
    for (int i = 0; i < MAX_CLIENT; i++)
        if (client_list_occupied[i]) return false; // isn't empty
    return true;
}


//*===== Function: Handle request =====*/
void *handle_client(void* thread_info)
{
    struct thread_info info = *((struct thread_info*)thread_info);
    int num = info.list_num;
    int client_sockfd = info.client_sockfd;
    sockaddr_in client_addr = info.client_addr;
    Server server = *(info.server);

    request_c(client_sockfd, client_addr);

    char buf[MAX_BUF];
    while (1)
    {
        ssize_t res = recv(client_sockfd, buf, MAX_BUF, 0);
        if (!res) break;

        string recv_str(buf);
        Packet recv_packet;
        auto recv = to_packet(recv_str);
        if (!recv.has_value())
            continue;
        else
            recv_packet = recv.value();

        cout << endl;
        cout << "\033[32m[System]\033[0m [client " << num + 1 << "]-handle request..." << endl;
        res = handle_request(recv_packet, info, num);

        if (res)
        {
            myServer.set_quit_flag();
            break;
        }
    }
    close(client_sockfd);
    std::lock_guard<std::mutex> lock(mutex);
    myServer.rst_client_list(num);

    if (myServer.is_quit_flag() && myServer.is_client_list_empty())
    {
        cout << "\033[32m[System]\033[0m All clients disconnect, successfully to quit server." << endl;
        close(myServer.get_server_sockfd());
        exit(0);
    }
    return 0;
}

int handle_request(Packet request, struct thread_info info, int request_id)
{
    char type = request.get_type();
    char dst = request.get_dst();
    string msg = request.get_msg();

    switch (type)
    {
        case 't': request_t(info.client_sockfd); break;
        case 'n': request_n(info.client_sockfd); break;
        case 'i': request_i(info.client_sockfd, *(info.server)); break;
        case 's': request_s(info.client_sockfd, request_id, dst, msg, *(info.server)); break;
        case 'd': request_d(info.client_sockfd); return 1;
        default: request_u(info.client_sockfd); break;
    }
    return 0;
}

void request_c(int client_sockfd, sockaddr_in client_addr) // connect
{
    stringstream ss;
    ss << "Client connect successfully. IP-" << inet_ntoa(client_addr.sin_addr) << ", port-" << ntohs(client_addr.sin_port);
    
    string msg = ss.str();
    Packet send_packet('c', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_t(int client_sockfd) // get time
{
    time_t time_;
    struct tm *p;
    time(&time_);
    p = localtime(&time_);
    stringstream ss;
    ss << 1900 + p->tm_year << "." << 1 + p->tm_mon << "." << p->tm_mday << " " << p->tm_hour << ":" << p->tm_min << ":" << p->tm_sec;
    
    string msg = ss.str();
    Packet send_packet('t', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_n(int client_sockfd) // get name
{
    char name[128];
    gethostname(name, sizeof(name));
    string msg(name);

    Packet send_packet('n', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_i(int client_sockfd, Server myServer) // get info list
{
    string msg = myServer.get_list();
    Packet send_packet('i', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_s(int client_sockfd, int client_id, char dst, string msg, Server myServer) // send msg
{
    int dst_sockfd = myServer.find_in_list(dst - 1);
    if (dst_sockfd == -1)
    {
        request_a(client_sockfd, "Target id isn't exist.");
        return;
    }
    string send_msg = "[client ";
    send_msg.push_back(client_id + 1 + '0');
    send_msg.append("]-");
    send_msg.append(msg);

    Packet send_packet('s', send_msg);
    cout << "\033[32m[System]\033[0m send msg: " << send_msg << endl;
    int ack = send(dst_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
    if (ack < 0)
        request_a(client_sockfd, "Failed to send msg.");
    else 
        request_a(client_sockfd, "Successfully send msg.");
    return;
}
void request_a(int client_sockfd, string msg) // answer
{
    Packet send_packet('a', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_d(int client_sockfd) // disconnect
{
    string msg("disconnect");
    Packet send_packet('d', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}
void request_u(int client_sockfd) // unknown
{
    string msg("[Error] unknown request type");
    Packet send_packet('u', msg);
    cout << "\033[32m[System]\033[0m send msg: " << msg << endl;
    send(client_sockfd, send_packet.to_string().c_str(), send_packet.to_string().size(), 0);
}

//*===== Main Function: Server =====*/
int main()
{
    myServer.server_on();
    return 0;
}
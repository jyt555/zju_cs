#ifndef _SERVER_H_
#define _SERVER_H_

#include "../packet/packet.h"

#define PORT 3450
#define MAX_WAITLOG 5
#define MAX_CLIENT 64
#define MAX_BUF 1024

using namespace std;

struct client_info
{
    int client_sockfd;
    sockaddr_in client_addr;
};

class Server
{
    private:
        int server_sockfd;
        sockaddr_in server_addr;
        map<int, struct client_info> client_list;
        int client_list_occupied[MAX_CLIENT];
        bool flag = false;
    public:
        Server();
        ~Server(){ close(server_sockfd); };
        void server_on();

        string get_list(); 
        void occupy_client_list(int num){ client_list_occupied[num] = 1; };
        void rst_client_list(int num); // reset
        int get_server_sockfd(){ return server_sockfd; };
        void set_quit_flag(){ flag = true; };
        bool is_quit_flag(){ return flag; };
        int get_list_num();
        int find_in_list(int id);
        bool is_client_list_empty();
};

struct thread_info
{
    int list_num;
    int client_sockfd;
    sockaddr_in client_addr;
    Server* server;
};

Server myServer;
void* handle_client(void* thread_info);
int handle_request(Packet request, struct thread_info info, int request_id);

void request_c(int client_sockfd, sockaddr_in client_addr); // connect
void request_t(int client_sockfd); // get time
void request_n(int client_sockfd); // get name
void request_i(int client_sockfd, Server myServer); // get info list
void request_s(int client_sockfd, int client_id, char dst, string msg, Server myServer); // send msg
void request_a(int client_sockfd, string msg); // answer
void request_d(int client_sockfd); // disconnect
void request_u(int client_sockfd); // unknown

#endif // end _SERVER_H_
3220103450-姜雨童-L2
|
|_codes
|   |_func.cpp
|   |_server(exe)
|   |_server.cpp
|   |_server.h
|
|_files
|   |_html
|   |  |_noimg.html
|   |  |_test.html
|   |_img
|   |  |_logo.jpg
|   |_txt
|   |  |_test.txt
|
|_readme.txt

Linux:
| compile[done]:
|   $ cd codes
|   $ g++ server.cpp -o server
| run:
|   $ ./server

Thanks :)
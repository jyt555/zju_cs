#ifndef _SERVER_H_
#define _SERVER_H_

#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <cerrno>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/mman.h>

const int BUF_SIZE = 2048;
const int SOCK_PORT = 3450;
const int MAX_CONNECTION = 100;

class Server {
public:
    Server();
    ~Server();
    int startAcceptClient();

private:
    pthread_t tid;
    int server_sock = -1; // haven't been created yet
    struct sockaddr_in server_addr;
};

#endif // end _SERVER_H_

#include "server.h"
using namespace std;

void parseHttpFromSock(char *method, char *uri, char *version, char *header, char *content, int fd)
{
    char ch;
    char buf[BUF_SIZE] = {};
    int res = -1;
    int line = 0; // 0:first line; 1:header; 2:blank line
    int length = 0;

    // get header
    for (int i = 0; i < BUF_SIZE; i++)
    {
        res = read(fd, &ch, 1);
        if (res > 0) {
            buf[i] = ch;
            if (ch == '\n')
            {
                if (line == 0) // first line
                {
                    sscanf(buf, "%s %s %s", method, uri, version);
                    memset(buf, 0, BUF_SIZE);
                    i = -1; // next line
                    line++;
                } else if (line == 1) // header
                {
                    if (strstr(buf, "Content-Length") != nullptr)
                        sscanf(buf, "Content-Length: %d", &length);
                    strcat(header, buf);
                    memset(buf, 0, BUF_SIZE);
                    i = -1;
                    line++;
                } else if (line == 2) // blank line
                    break;
            } else {
                if (line == 2 && ch != '\r')
                    line--;
            }
        }
    }

    // get content
    for (int i = 0; i < length; i++) {
        read(fd, &ch, 1);
        content[i] = ch;
    }
}

/* ===== analyse File info ===== */
void getFileName(char *uri) {
    char buf[BUF_SIZE] = {};
    ::strcpy(buf, "../files");
    ::strcat(buf, uri);
    ::strcpy(uri, buf);
}
void getFileType(char* file_name, char* file_type) {
    if (strstr(file_name, ".html"))
        strcpy(file_type, "text/html");
    else if (strstr(file_name, ".jpg"))
        strcpy(file_type, "image/jpeg");
    else
        strcpy(file_type, "text/plain");
}

/* ===== interaction with client ===== */
void clientSendMsg(int fd, char* n, char* msg)
{
    char content[BUF_SIZE] = {};
    char buf[BUF_SIZE] = {};

    if (!::strcmp(n, "200"))
        sprintf(content, "<html><body>%s</body></html>", msg);
    
    sprintf(buf + ::strlen(buf), "HTTP/1.0 %s %s\r\n", n, msg);
    sprintf(buf + ::strlen(buf), "Content-Type: text/html\r\n");
    sprintf(buf + ::strlen(buf), "Content-Length: %d\r\n\r\n", (int)strlen(content)); //*
    ::strcat(buf, content);
    printf("\33[33mClient send Msg:\33[0m\n");
    printf("\33[34m%s\33[0m\n", buf);
    printf("\33[33m============================\33[0m\n");

    write(fd, buf, ::strlen(buf));
}
void clientSendFile(int fd, char*uri, off_t size)
{
    char* mapped_fp;
    char  file_type[BUF_SIZE] = {};
    char  buf[BUF_SIZE] = {};

    getFileType(uri, file_type);
    sprintf(buf, "HTTP/1.0 200 ok\r\n");
    sprintf(buf, "%sServer: A Web Server\r\n", buf);
    sprintf(buf, "%sConnection: open\r\n", buf);
    sprintf(buf, "%sContent-Length: %ld\r\n", buf, size);
    sprintf(buf, "%sContent-Type: %s\r\n\r\n", buf, file_type);

    write(fd, buf, ::strlen(buf));
    printf("\33[33mClient send File.header: \33[0m\n");
    printf("\33[34m%s\33[0m", buf);
    printf("\33[33m============================\33[0m\n");

    int file_fd = open(uri, O_RDONLY, 0);
    mapped_fp = (char*)mmap(nullptr, size, PROT_READ, MAP_PRIVATE, file_fd, 0);

    write(fd, mapped_fp, size);
    printf("\33[33mClient send File.content: \33[0m\n");
    printf("\33[34m%s\33[0m\n\n", mapped_fp);
    printf("\33[33m============================\33[0m\n");

    munmap(mapped_fp, size);
    close(fd);
}
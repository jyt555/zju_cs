#include "func.cpp"
using namespace std;

/* ===== Class Server ===== */
Server::Server()
{
    printf("\33[33m========= Server ===========\33[0m\n");

    // socket()
    server_sock = socket(AF_INET, SOCK_STREAM, 0); // AF_INET: IPv4
    cout << "\33[32msocket() finished. server_sock: " << server_sock << "\33[0m" << endl;

    // bind()
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(SOCK_PORT);
    int res = ::bind(server_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr));
    if (res == -1)
    {
        cout << "\33[31mbind() error " << errno << ": " << strerror(errno) << "\33[0m" << endl;
        exit(errno);
    }else
        cout << "\33[32mbind() finished. IP: " << htonl(INADDR_ANY) << "\33[0m" << endl;

    // listen()
    res = listen(server_sock, MAX_CONNECTION);
    if (res == -1) {
        cout << "\33[31mlisten() error " << errno << ": " << strerror(errno) << "\33[0m" << endl;
        exit(errno);
    } else
        cout << "\33[32mlisen() finished." << "\33[0m" << endl;
    printf("\33[33m============================\33[0m\n");
}
Server::~Server()
{
    if (server_sock >= 0) {
        close(server_sock);
        server_sock = -1;
    }
}

void *handleRequest(void *arg);
int Server::startAcceptClient()
{
    int client_sock = -1;
    struct sockaddr_in client_addr;
    socklen_t client_addr_size = sizeof(client_addr);
    while (true) // keep accept client's connection
    {
        client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_size);
        if (client_sock == -1)
            cout << "\33[31mcan not connect.\33[0m" << endl;
        else {
            cout << "\33[32mconnect successfully.\33[0m" << endl;
            cout << "\33[32m|_client IP: " << client_addr.sin_addr.s_addr <<"\33[0m" << endl;
            cout << "\33[32m|_client port: " << ntohs(client_addr.sin_port) << "\33[0m" << endl;

            pthread_t tid;
            pthread_create(&tid, NULL, &handleRequest, (void*)&client_sock);
        }
        printf("\33[33m============================\33[0m\n");
    }
    return 0;
}
void *handleRequest(void *arg)
{
    int sock = *(int *) arg;

    char method[BUF_SIZE];
    char uri[BUF_SIZE];
    char version[BUF_SIZE];
    char header[BUF_SIZE];
    char content[BUF_SIZE];
    struct stat file_stat;

    parseHttpFromSock(method, uri, version, header, content, sock);

    if (!::strcasecmp(method, "GET"))
    {
        getFileName(uri);
        if (stat(uri, &file_stat) < 0) // cannot find the file
            clientSendMsg(sock, "404", "Not found");
        else if ((S_IRUSR & file_stat.st_mode) == 0) // have no auth. to open the file
            clientSendMsg(sock, "403", "Forbidden");
        else //response
            clientSendFile(sock, uri, file_stat.st_size);
    }
    else if (!::strcasecmp(method, "POST"))
    {
        if (strcmp(uri, "/html/dopost")) // if the uri is not dopost
            clientSendMsg(sock, "404", "Not found");
        else if (!strcmp(content, "login=3220103450&pass=3450"))
            clientSendMsg(sock, "200", "successfully log in.");
        else
            clientSendMsg(sock, "200", "fail to log in.");
    }
    pthread_exit(nullptr);
}


/* ===== Main Mehod =====*/
int main()
{
    Server *myServer = new Server();
    myServer->startAcceptClient();
    return 0;
}